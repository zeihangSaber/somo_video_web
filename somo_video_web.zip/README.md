## somo_video_web

web会议客户端

http://localhost:1111/#/?cookie=MTAwMDAwNTAtMTU2MjU3MTg0MDIzNy01MDk0MzQ0&name=111&uid=10000050&mobile=18559657700&mid=14808&tenant=0

http://localhost:1111/#/?cookie=MTAwMDAwNTItMTU2MDczNTYxODQzNC0yMzYxNTY4&name=111&uid=10000052&mobile=18559657700&mid=14808&tenant=0